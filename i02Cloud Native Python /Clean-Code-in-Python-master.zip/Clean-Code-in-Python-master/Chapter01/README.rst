Chapter 01 - Introduction, Tools, and Formatting
================================================

Install dependencies::

   make setup

Run the  tests::

   make test
