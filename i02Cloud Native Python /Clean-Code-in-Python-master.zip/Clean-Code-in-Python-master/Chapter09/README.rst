Clean code in Python - Chapter 09: Common design patterns
=========================================================

Run tests with::

    make test