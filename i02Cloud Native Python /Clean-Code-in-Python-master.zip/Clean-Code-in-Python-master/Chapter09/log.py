import logging

logging.basicConfig()
logger = logging.getLogger(__name__)
