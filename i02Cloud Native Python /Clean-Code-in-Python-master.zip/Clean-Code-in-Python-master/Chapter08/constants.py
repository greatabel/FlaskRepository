"""Definitions"""

STATUS_ENDPOINT = "http://localhost:8080/mrstatus"
