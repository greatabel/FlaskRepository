Chapter 04: The SOLID Principles
================================

Run tests::

    make test