Chapter 03 - General traits of good code
========================================

Run the tests::

    make test