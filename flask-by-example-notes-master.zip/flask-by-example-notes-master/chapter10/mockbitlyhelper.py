class MockBitlyHelper:

	def shorten_url(self, long_url):
		return long_url
